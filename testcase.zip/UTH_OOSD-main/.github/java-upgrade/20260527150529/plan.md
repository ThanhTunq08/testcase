# Upgrade Plan: backend (20260527150529)

- **Generated**: 2026-05-27 15:10:00
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17.0.17: C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot\bin
- JDK 25: **<TO_BE_INSTALLED>** (required by steps 1, 3, and 4)

**Build Tools**
- Maven 3.9.12: C:\Program Files\apache-maven-3.9.12\bin
- Maven 4.0+: **<TO_BE_INSTALLED>** (required by steps 1, 3, and 4 for Java 25 compatibility)

## Guidelines

- Upgrade the backend runtime to the latest Java LTS version.
- Preserve existing Spring Boot 3.2.5 compatibility where possible.
- Keep tests enabled and ensure the full test suite passes after the upgrade.

## Options

- Working branch: appmod/java-upgrade-20260527150529
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java runtime from 17 to 25 for the backend Maven project in `backend/pom.xml`.

### Technology Stack

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| --------------------- | ------- | -------------- | ---------------- |
| Java | 17 | 25 | User requested latest LTS runtime upgrade |
| Spring Boot | 3.2.5 | 3.2.5 | Current version is baseline; runtime compatibility with Java 25 must be verified |
| Maven | 3.9.12 | 4.0.0 | Java 25 requires newer Maven build tool compatibility |
| maven-compiler-plugin | managed by Spring Boot BOM | 3.11.0 | Required for compiling Java 25 release target |
| maven-surefire-plugin | managed by Spring Boot BOM | 3.1.2 | Recommended for reliable test execution on newer JDKs |

### Derived Upgrades

- Install JDK 25 and use it for the final runtime target, because the user requested the latest LTS version.
- Upgrade Maven to 4.0+ for Java 25 build tool compatibility, because Maven 3.9.x may not fully support the latest JDK runtime.
- Explicitly configure `maven-compiler-plugin` 3.11.0 and `maven-surefire-plugin` 3.1.2 in `backend/pom.xml` to ensure correct Java 25 compilation and test execution.
- Update `backend/pom.xml` property `<java.version>` from `17` to `25` to move the project source/target baseline to the new runtime.

## Upgrade Steps

- Step 1: Setup Environment
  - Rationale: The current system only has JDK 17 installed. Java 25 and a compatible Maven installation are required before changing the project runtime target.
  - Changes to Make:
    - [ ] Install JDK 25 on the machine or configure it if already available.
    - [ ] Install or make available Maven 4.0+ for Java 25 compilation support.
    - [ ] Verify the installed JDK and Maven versions are available in the environment used for plan execution.
  - Verification:
    - Command: `#appmod-list-jdks` and `#appmod-list-mavens`; then `mvn -version` with the selected Maven
    - Expected Result: JDK 25 and Maven 4.0+ are discoverable and usable.

- Step 2: Setup Baseline
  - Rationale: Establish the current compile and test baseline on Java 17 before upgrading the runtime.
  - Changes to Make:
    - [ ] Run baseline compilation and tests against `backend/pom.xml` using the current JDK 17 setup.
    - [ ] Record the baseline status and any pre-existing failures.
  - Verification:
    - Command: `mvn -f backend/pom.xml clean test-compile -q && mvn -f backend/pom.xml test -q`
    - JDK: 17
    - Expected Result: Baseline compile and tests run successfully, or any existing failures are documented.

- Step 3: Upgrade runtime target and build plugins
  - Rationale: Explicitly set the project to Java 25 and update build plugins required for newer JDK compatibility before final validation.
  - Changes to Make:
    - [ ] Update `<java.version>` in `backend/pom.xml` from `17` to `25`.
    - [ ] Add or pin `maven-compiler-plugin` to version `3.11.0` with `<release>25</release>`.
    - [ ] Add or pin `maven-surefire-plugin` to version `3.1.2` to support tests on the upgraded JDK.
    - [ ] Retain Spring Boot 3.2.5 unless compatibility issues require a later Spring Boot upgrade.
  - Verification:
    - Command: `mvn -f backend/pom.xml clean test-compile -q`
    - JDK: 25
    - Expected Result: Compilation succeeds with Java 25.

- Step 4: Final Validation
  - Rationale: Validate the completed upgrade by rebuilding the project and running the full test suite on the target runtime.
  - Changes to Make:
    - [ ] Resolve any remaining compilation or test issues uncovered after switching to Java 25.
    - [ ] Ensure the `backend/pom.xml` reflects the final Java target and plugin versions.
    - [ ] Remove any temporary workarounds and verify the codebase is stable.
  - Verification:
    - Command: `mvn -f backend/pom.xml clean test -q`
    - JDK: 25
    - Expected Result: Compilation and tests succeed with 100% pass rate.

## Key Challenges

- **Java 25 Runtime Compatibility**
  - Challenge: The project currently targets Java 17, so the upgrade requires ensuring all build tooling and runtime dependencies support Java 25.
  - Strategy: Install Java 25 and Maven 4.x, then explicitly pin build plugins for Java 25 compatibility. Validate compilation and tests on the upgraded runtime.

- **Build Tool Compatibility**
  - Challenge: Maven 3.9.12 is present, but Java 25 requires Maven 4.0+ for the most reliable build experience and toolchain support.
  - Strategy: Install or configure Maven 4.x in step 1 and use it for upgrade and validation steps.

- **Plugin Version Management**
  - Challenge: The project currently relies on Spring Boot BOM defaults for compiler and surefire plugin versions, which may not be sufficient for the newest JDK.
  - Strategy: Explicitly declare `maven-compiler-plugin` 3.11.0 and `maven-surefire-plugin` 3.1.2 in `backend/pom.xml`.
